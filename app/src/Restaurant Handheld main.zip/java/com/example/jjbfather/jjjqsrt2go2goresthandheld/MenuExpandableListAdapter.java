package com.example.jjbfather.jjjqsrt2go2goresthandheld;


import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MenuExpandableListAdapter extends BaseExpandableListAdapter {
   private Context context;
   private List<String> expandableTitleList;
   private HashMap<String, List<String>> expandableDetailList;

   private List<String> expandableTitleList_data;
   private HashMap<String, List<TemporaryServiceInfo>> expandableListDetail_data;

   // constructor
   public MenuExpandableListAdapter(Context context, List<String> expandableListTitle,
                                    HashMap<String, List<String>> expandableListDetail, List<String> expandableTitleList_data, HashMap<String, List<TemporaryServiceInfo>> expandableListDetail_data) {
      this.context = context;
      this.expandableTitleList = expandableListTitle;
      this.expandableDetailList = expandableListDetail;

      this.expandableTitleList_data = expandableTitleList_data;
      this.expandableListDetail_data = expandableListDetail_data;
   }

   @Override
   // Gets the data associated with the given child within the given group.
   public Object getChild(int lstPosn, int expanded_ListPosition) {
      return this.expandableDetailList.get(this.expandableTitleList.get(lstPosn)).get(expanded_ListPosition);
   }

   @Override
   // Gets the ID for the given child within the given group.
   // This ID must be unique across all children within the group. Hence we can pick the child uniquely
   public long getChildId(int listPosition, int expanded_ListPosition) {
      return expanded_ListPosition;
   }

   @Override
   // Gets a View that displays the data for the given child within the given group.
   public View getChildView(int lstPosn, final int expanded_ListPosition,
                            boolean isLastChild, View convertView, ViewGroup parent) {
      final String expandedListText = (String) getChild(lstPosn, expanded_ListPosition);
      if (convertView == null) {
         LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
         convertView = layoutInflater.inflate(R.layout.fragment_menu_menulist_item, null);
      }

      String[] items = expandedListText.split(GlobalMemberValues.STRSPLITTER1);
      String itemname = items[2];
      String itemprice = items[6];

      TextView expandedListTextView = (TextView) convertView.findViewById(R.id.expandedListItem);
      expandedListTextView.setText(itemname);

      TextView menupriceTextView = convertView.findViewById(R.id.expandedListItemPrice);

      menupriceTextView.setText(GlobalMemberValues.getCommaStringForDouble(itemprice));

      Button button = convertView.findViewById(R.id.expandedListItemButton);

      // Service 의 정보를 임시로 저장하기 위한 클래스인 TemporaryServiceInfo 를 이용하여 카테고리정보 저장
      List<TemporaryServiceInfo> temporaryServiceInfoList = expandableListDetail_data.get(expandableTitleList.get(lstPosn));
//      TemporaryServiceInfo tempServiceInfo = expandableListDetail_data.get(expandableTitleList.get(lstPosn)).get(expanded_ListPosition);
      TemporaryServiceInfo tempServiceInfo;
      if (temporaryServiceInfoList.size() > expanded_ListPosition){
         tempServiceInfo = temporaryServiceInfoList.get(expanded_ListPosition);
      } else {
         return convertView;
      }
//      TemporaryServiceInfo tempServiceInfo = temporaryServiceInfoList.get(expanded_ListPosition);
//      tempServiceInfo = MainMiddleService.list_TemporaryServiceInfo.get(expandableTitleList.get(lstPosn)).get(expanded_ListPosition);

      // 위에서 생성한 클래스를 Tag 값으로 저장 (setTag)
      // setTag 로 객체 저장시 서비스 버튼의 아이디를 KEY 값으로 사용한다.
      if (tempServiceInfo != null) {

         convertView.setTag(convertView.getId(), tempServiceInfo);
         button.setTag(button.getId(), tempServiceInfo);
         button.setText(itemname);
//         menuname.setTag(menuname.getId(), tempServiceInfo);
      }

      if (!GlobalMemberValues.isStrEmpty(expandedListText)) {
//         if (tempIndex == 0) {
//            mTouchedView_fromMenuSearch = middleServiceBtn;
//         }
//         tempIndex++;
         // 서비스버튼 클릭시 이벤트
//         convertView.setOnClickListener(mServiceButtonListner);
//         middleServiceNameText.setOnClickListener(mServiceTextViewListner);
//         middleServicePriceText.setOnClickListener(mServicePriceTextViewListner);
//                        middleServiceNameText.setOnClickListener(mServiceButtonListner);
         // 서비스버튼 길게 클릭시 이벤트
         button.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
               Intent serviceDetailPopupIntent = new Intent(MainActivity.mContext, ServiceDetailPopup.class);
               serviceDetailPopupIntent.putExtra("ServiceIdx", tempServiceInfo.svcIdx);
               MainActivity.mActivity.startActivity(serviceDetailPopupIntent);
               if (GlobalMemberValues.isUseFadeInOut()) {
                  MainActivity.mActivity.overridePendingTransition(R.anim.act_in_left, R.anim.act_out_left);
               }
               return true;
            }
         });
      }

      button.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
               // 네트워크 상태 체크
               GlobalMemberValues.checkOnlineService(MainActivity.mContext, MainActivity.mActivity);

               // All Discount / Extra 가 실행된지 체크후 -------------------------------
               // 실행후라면 이후의 코드를 실행하지 않는다.
               if (!MainMiddleService.checkAllDiscountExtra()) return;
               // -----------------------------------------------------------------------

               // 선택한 직원 체크
               if (GlobalMemberValues.GLOBAL_EMPLOYEEINFO == null) {
                  GlobalMemberValues.displayDialog(context, "Warning", "Choose a employee", "Close");
                  return;
               } else {
                  // ADMIN 접속일 경우 선택못하게..
                  if (GlobalMemberValues.isStrEmpty(GlobalMemberValues.GLOBAL_EMPLOYEEINFO.empIdx)) {
                     GlobalMemberValues.displayDialog(context, "Warning", "Choose a employee", "Close");
                     return;
                  }
               }

               Button btn = (Button)v;
               if (!GlobalMemberValues.isStrEmpty(btn.getText().toString())) {
                  // 현재 클릭한 서비스버튼에 Tag 저장되어 있는 TemporaryCategory 객체를 가져온다.
                  TemporaryServiceInfo tempCif = (TemporaryServiceInfo)btn.getTag(btn.getId());
                  // ★★★★★★★★반드시 해당 객체가 있는지 체크해 준다★★★★★★★★
                  MainMiddleService.selectService(tempCif, btn);

               }



         }
      });


      return convertView;
   }

   @Override
   // Gets the number of children in a specified group.
   public int getChildrenCount(int listPosition) {

      return this.expandableDetailList.get(this.expandableTitleList.get(listPosition)).size();
   }

   @Override
   // Gets the data associated with the given group.
   public Object getGroup(int listPosition) {
      return this.expandableTitleList.get(listPosition);
   }

   @Override
   // Gets the number of groups.
   public int getGroupCount() {
      return this.expandableTitleList.size();
   }

   @Override
   // Gets the ID for the group at the given position. This group ID must be unique across groups.
   public long getGroupId(int listPosition) {
      return listPosition;
   }

   @Override
   // Gets a View that displays the given group.
   // This View is only for the group--the Views for the group's children
   // will be fetched using getChildView()
   public View getGroupView(int listPosition, boolean isExpanded, View convertView, ViewGroup parent) {
      String listTitle = (String) getGroup(listPosition);
      if (convertView == null) {
         LayoutInflater layoutInflater = (LayoutInflater) this.context.
                 getSystemService(Context.LAYOUT_INFLATER_SERVICE);
         convertView = layoutInflater.inflate(R.layout.fragment_menu_menulist_group, null);
      }
      TextView listTitleTextView = (TextView) convertView.findViewById(R.id.listTitle);
      listTitleTextView.setTypeface(null, Typeface.BOLD);
      if (!listTitle.isEmpty()){
         listTitle = listTitle.replace("\n", " ");
      }
      listTitleTextView.setText(listTitle);

      return convertView;
   }

   @Override
   // Indicates whether the child and group IDs are stable across changes to the underlying data.
   public boolean hasStableIds() {
      return false;
   }

   @Override
   // Whether the child at the specified position is selectable.
   public boolean isChildSelectable(int listPosition, int expandedListPosition) {
      return true;
   }
}
