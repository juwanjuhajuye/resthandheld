package com.example.jjbfather.jjjqsrt2go2goresthandheld;

import android.app.Activity;
import android.os.Bundle;

import com.example.jjbfather.jjjqsrt2go2goresthandheld.R;

public class TabTestPage extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tab_test_page);
    }
}
