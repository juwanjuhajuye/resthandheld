package com.example.jjbfather.jjjqsrt2go2goresthandheld;

public interface CustomDialogClickListener {
    void onPositiveClick();
    void onMiddClick();
    void onNegativeClick();
}