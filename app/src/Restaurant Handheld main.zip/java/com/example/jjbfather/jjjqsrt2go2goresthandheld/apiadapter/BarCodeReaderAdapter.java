package com.example.jjbfather.jjjqsrt2go2goresthandheld.apiadapter;

/**
 * Created by elo on 9/11/17.
 */

public interface BarCodeReaderAdapter {
    public boolean isBarCodeReaderEnabled();

    public void setBarCodeReaderEnabled(boolean enabled);

    public boolean isBarCodeReaderKbdMode();

    public void setBarCodeReaderKbdMode();
}
