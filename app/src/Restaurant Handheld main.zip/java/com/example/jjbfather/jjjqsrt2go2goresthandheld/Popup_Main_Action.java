package com.example.jjbfather.jjjqsrt2go2goresthandheld;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Popup_Main_Action extends Dialog {


    private Button btn_close;
    private Button btn_pay;
    private Button btn_setting, popup_main_action_server, popup_main_action_discount,popup_main_action_quick,popup_main_action_product,popup_main_action_giftcard,popup_main_action_menusearch,popup_main_action_logout;

    private Button btn_print, btn_general_modifier, btn_add_divider, btn_taxexempt, btn_remove_taxexempt, btn_remove_gratuity;

    private View.OnClickListener mCloseClickListener;
    private View.OnClickListener mPayClickListener;
    private View.OnClickListener mSettingClickListener;
    private View.OnClickListener mClickListener;



    private View.OnClickListener mMainMiddleServiceClickListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.popup_main_action);

        setLayout();
        setClickListener(mCloseClickListener, mPayClickListener, mSettingClickListener, mClickListener, mMainMiddleServiceClickListener);
    }

    public Popup_Main_Action(Context context , View.OnClickListener singleListener, View.OnClickListener payListener, View.OnClickListener settingListener, View.OnClickListener clickListener, View.OnClickListener mMainMiddleServiceClickListener) {
        //super(context);
        super(context , android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        this.mCloseClickListener = singleListener;
        this.mPayClickListener = payListener;
        this.mSettingClickListener = settingListener;
        this.mClickListener = clickListener;
        this.mMainMiddleServiceClickListener = mMainMiddleServiceClickListener;
    }

    private void setClickListener(View.OnClickListener close, View.OnClickListener pay, View.OnClickListener setting, View.OnClickListener clickListener, View.OnClickListener mMainMiddleServiceClickListener){
        if(close!=null){
            btn_close.setOnClickListener(close);
        }
        if (pay!= null){
            btn_pay.setOnClickListener(pay);
        }
        if (setting != null){
            btn_setting.setOnClickListener(setting);
        }
        if (clickListener != null){
            popup_main_action_server.setOnClickListener(clickListener);
            popup_main_action_discount.setOnClickListener(clickListener);
            popup_main_action_quick.setOnClickListener(clickListener);
            popup_main_action_product.setOnClickListener(clickListener);
            popup_main_action_giftcard.setOnClickListener(clickListener);
            popup_main_action_menusearch.setOnClickListener(clickListener);
            popup_main_action_logout.setOnClickListener(clickListener);

            btn_print.setOnClickListener(clickListener);
//            btn_general_modifier.setOnClickListener(mMainMiddleServiceClickListener);
            btn_add_divider.setOnClickListener(clickListener);
            btn_taxexempt.setOnClickListener(clickListener);
            btn_remove_taxexempt.setOnClickListener(mMainMiddleServiceClickListener);
            btn_remove_gratuity.setOnClickListener(clickListener);
        }

    }



    /*
     * Layout
     */
    private void setLayout(){
        btn_pay = (Button) findViewById(R.id.popup_main_action_pay);
        btn_close = (Button) findViewById(R.id.popup_main_action_close);
        btn_setting = (Button) findViewById(R.id.popup_main_action_setting);
        popup_main_action_server = (Button) findViewById(R.id.popup_main_action_server);
        popup_main_action_discount = (Button) findViewById(R.id.popup_main_action_discount);
        popup_main_action_quick = (Button) findViewById(R.id.popup_main_action_quick);
        popup_main_action_product = (Button) findViewById(R.id.popup_main_action_product);
        popup_main_action_giftcard = (Button) findViewById(R.id.popup_main_action_giftcard);
        popup_main_action_menusearch = (Button) findViewById(R.id.popup_main_action_menusearch);
        popup_main_action_logout = (Button) findViewById(R.id.popup_main_action_logout);


        btn_print = (Button) findViewById(R.id.popup_main_action_print);
        btn_general_modifier = (Button) findViewById(R.id.popup_main_action_general_modifier);
        btn_add_divider = (Button) findViewById(R.id.popup_main_action_add_divider);
        btn_taxexempt = (Button) findViewById(R.id.popup_main_action_tax_exempt);
        btn_remove_taxexempt = (Button) findViewById(R.id.popup_main_action_remove_tax_exempt);
        btn_remove_gratuity = (Button) findViewById(R.id.popup_main_action_remove_gratuity);
    }

}