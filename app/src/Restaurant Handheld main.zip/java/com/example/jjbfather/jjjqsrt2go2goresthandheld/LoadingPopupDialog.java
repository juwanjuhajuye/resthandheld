package com.example.jjbfather.jjjqsrt2go2goresthandheld;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.view.LayoutInflater;
import android.widget.ProgressBar;
import android.widget.TextView;

public class LoadingPopupDialog {
    // 2 objects activity and dialog
    private Activity activity;
    private AlertDialog dialog;

    private Boolean dialogExists = false;

    // constructor of dialog class
    // with parameter activity
    public LoadingPopupDialog(Activity myActivity) {
        activity = myActivity;
    }

    @SuppressLint("InflateParams")
    public void startLoadingdialog(boolean invisibleLoadingBar) {
        if(!dialogExists){
            GlobalMemberValues.logWrite("LoadingPopupDialog", "popup dialog started");

            // adding ALERT Dialog builder object and passing activity as parameter
            AlertDialog.Builder builder = new AlertDialog.Builder(activity);

            // layoutinflater object and use activity to get layout inflater
            LayoutInflater inflater = activity.getLayoutInflater();

            if(invisibleLoadingBar){
                builder.setView(inflater.inflate(R.layout.loading_popup_invisible_bar, null));
            } else {
                builder.setView(inflater.inflate(R.layout.loading_popup, null));
            }

            builder.setCancelable(true);



            dialog = builder.create();
            dialog.setCancelable(false);
            dialog.setCanceledOnTouchOutside(false);


            dialog.show();
            dialogExists = true;
        } else {
            GlobalMemberValues.logWrite("LoadingPopupDialog", "popup dialog already exists!");
        }


    }

    // dismiss method
    public void dismissdialog() {
        if(dialog != null && dialogExists){
            GlobalMemberValues.logWrite("LoadingPopupDialog", "popup dialog dismissed");
            dialog.dismiss();
            dialogExists = false;
        }
    }
}
