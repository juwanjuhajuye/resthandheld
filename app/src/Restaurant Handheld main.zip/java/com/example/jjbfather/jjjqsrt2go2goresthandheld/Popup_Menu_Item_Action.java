package com.example.jjbfather.jjjqsrt2go2goresthandheld;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class Popup_Menu_Item_Action extends Dialog {

    private Button close_btn;
    private Button modifier_btn;
    private Button each_discount_btn;
    private Button tax_exempt_btn;
    private Button tax_exempt_cancel_btn;

    private View.OnClickListener mGeneralModifierClickListener;
    private View.OnClickListener mEachDiscountClickListener;
    private View.OnClickListener mTaxExemptClickListener;
    private View.OnClickListener mTaxExemptCancelClickListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);

        setContentView(R.layout.popup_menu_item_action);

        setLayout();
        setClickListener(mGeneralModifierClickListener, mEachDiscountClickListener, mTaxExemptClickListener, mTaxExemptCancelClickListener);
    }

    public Popup_Menu_Item_Action(Context context, View.OnClickListener generalModifierListener, View.OnClickListener eachDiscountListener, View.OnClickListener taxExemptListener,
                                  View.OnClickListener taxExemptCancelListener) {
        //super(context);
        super(context , android.R.style.Theme_Black_NoTitleBar_Fullscreen);

        this.mGeneralModifierClickListener = generalModifierListener;
        this.mEachDiscountClickListener = eachDiscountListener;
        this.mTaxExemptClickListener = taxExemptListener;
        this.mTaxExemptCancelClickListener = taxExemptCancelListener;
    }

    /*
     * Layout
     */
    private void setLayout(){
        close_btn = (Button) findViewById(R.id.popup_menu_item_action_close);

        modifier_btn = (Button) findViewById(R.id.popup_menu_item_action_general_modifier);
        tax_exempt_btn = (Button) findViewById(R.id.popup_menu_item_action_tax_exempt);
        tax_exempt_cancel_btn = (Button) findViewById(R.id.popup_menu_item_action_remove_tax_exempt);
        each_discount_btn = (Button) findViewById(R.id.popup_menu_item_action_discount);

    }
    private void setClickListener(View.OnClickListener generalModifierListener, View.OnClickListener eachDiscountListener, View.OnClickListener taxExemptListener,
                                  View.OnClickListener taxExemptCancelListener){

            close_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dismiss();
                }
            });

            modifier_btn.setOnClickListener(generalModifierListener);
            tax_exempt_btn.setOnClickListener(taxExemptListener);
            tax_exempt_cancel_btn.setOnClickListener(taxExemptCancelListener);
            each_discount_btn.setOnClickListener(eachDiscountListener);

    }


}