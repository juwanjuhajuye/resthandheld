package com.example.jjbfather.jjjqsrt2go2goresthandheld.apiadapter;

/**
 * Created by oren on 9/8/17.
 */

public interface CashDrawerAdapter {

    public boolean isCashDrawerOpen();

    public void openCashDrawer();
}
