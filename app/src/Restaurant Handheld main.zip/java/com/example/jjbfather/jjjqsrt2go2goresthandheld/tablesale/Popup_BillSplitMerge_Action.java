package com.example.jjbfather.jjjqsrt2go2goresthandheld.tablesale;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import androidx.annotation.NonNull;

import com.example.jjbfather.jjjqsrt2go2goresthandheld.R;

public class Popup_BillSplitMerge_Action extends Dialog {

    Button popup_billsplitmerge_merge_selected, popup_billsplitmerge_reset_selected, popup_billsplitmerge__resert_all, popup_billsplitmerge_selected_printing, popup_billsplitmerge_void_by_bills, popup_billsplitmerge_pay_by_bills, popup_billsplitmerge_close;
    View.OnClickListener onClickListener;
    public Popup_BillSplitMerge_Action(@NonNull Context context, View.OnClickListener onClickListener) {
        super(context);
        this.onClickListener = onClickListener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);


        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.popup_billsplitmerge_action);

        setLayout();
        setClickListener(onClickListener);
    }

    private void setLayout(){
        popup_billsplitmerge_merge_selected = (Button)findViewById(R.id.popup_billsplitmerge_merge_selected);
        popup_billsplitmerge_reset_selected = (Button)findViewById(R.id.popup_billsplitmerge_reset_selected);
        popup_billsplitmerge__resert_all = (Button)findViewById(R.id.popup_billsplitmerge__resert_all);
        popup_billsplitmerge_selected_printing = (Button)findViewById(R.id.popup_billsplitmerge_selected_printing);
        popup_billsplitmerge_void_by_bills = (Button)findViewById(R.id.popup_billsplitmerge_void_by_bills);
        popup_billsplitmerge_pay_by_bills = (Button)findViewById(R.id.popup_billsplitmerge_pay_by_bills);
        popup_billsplitmerge_close = (Button)findViewById(R.id.popup_billsplitmerge_close);
    }

    private void setClickListener(View.OnClickListener onClickListener){
        popup_billsplitmerge_merge_selected.setOnClickListener(onClickListener);
        popup_billsplitmerge_reset_selected.setOnClickListener(onClickListener);
        popup_billsplitmerge__resert_all.setOnClickListener(onClickListener);
        popup_billsplitmerge_selected_printing.setOnClickListener(onClickListener);
        popup_billsplitmerge_void_by_bills.setOnClickListener(onClickListener);
        popup_billsplitmerge_pay_by_bills.setOnClickListener(onClickListener);
        popup_billsplitmerge_close.setOnClickListener(onClickListener);
    }
}
