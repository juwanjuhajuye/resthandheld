package com.example.jjbfather.jjjqsrt2go2goresthandheld;

import static androidx.core.content.ContextCompat.getSystemService;

import android.app.ActionBar;
import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;

public class Popup_table_floor_list extends Dialog {

    private Context mContext;
    private String title, mainTxt;

    private ListView listView;
    private String[] listArray;
    private AdapterView.OnItemClickListener listener;

    public Popup_table_floor_list(Context context, String[] maintxt, AdapterView.OnItemClickListener listener) {
        super(context);
        //super(context , android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        this.mContext = context;
        this.listArray = maintxt;
        this.listener = listener;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.popup_table_floor_list);

        listView = (ListView) findViewById(R.id.popup_table_floor_list_list);
        listView.setAdapter(new FloorlistArrayAdapter(mContext,R.layout.table_main_floor_list_row,listArray));
        listView.setOnItemClickListener(listener);
    }

    public class FloorlistArrayAdapter extends android.widget.ArrayAdapter{
        private String[] listArray;
        private Context mContext;

        public FloorlistArrayAdapter(Context context, int resource, String[] listarray) {
            super(context, resource, listarray);
            this.mContext = context;
            this.listArray = listarray;
        }
        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(R.layout.table_main_floor_list_row, null);
            }

            String str_floor_name = listArray[position];

            if(str_floor_name != null){
                TextView tv_name = (TextView) v.findViewById(R.id.floor_title_name);
                if (tv_name != null){
                    tv_name.setText(str_floor_name);
                }
            }

            return v;
        }
    }
}
