package com.example.jjbfather.jjjqsrt2go2goresthandheld.tablesale;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import com.example.jjbfather.jjjqsrt2go2goresthandheld.R;

public class Popup_Table_Action extends Dialog {


    private Button btn_close;
    private Button btn_pay, table_main_btn_billprint, table_main_btn_splitmergeprint, table_main_btn_detailinfo, table_main_btn_movetable, table_main_btn_tablesplit, table_main_btn_tablemerge, table_main_btn_tableclear, table_main_btn_bellstop;

    // 08092023
    private Button table_main_btn_tablecombine;

    private View.OnClickListener mCloseClickListener;
    private View.OnClickListener mPayClickListener;
    private View.OnClickListener clickListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WindowManager.LayoutParams lpWindow = new WindowManager.LayoutParams();

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        lpWindow.flags = WindowManager.LayoutParams.FLAG_DIM_BEHIND;
        lpWindow.dimAmount = 0.8f;
        getWindow().setAttributes(lpWindow);


        setContentView(R.layout.popup_table_action);

        setLayout();
        setClickListener(mCloseClickListener, clickListener);
    }

    public Popup_Table_Action(Context context , View.OnClickListener singleListener, View.OnClickListener clickListener) {
//        super(context , android.R.style.Theme_Translucent_NoTitleBar);
        super(context);
        this.mCloseClickListener = singleListener;
//        this.mPayClickListener = payListener;
        this.clickListener = clickListener;
    }

    private void setClickListener(View.OnClickListener close, View.OnClickListener clickListener){
        if(close!=null){
            btn_close.setOnClickListener(close);
        }
        if(clickListener!= null){
            table_main_btn_billprint.setOnClickListener(clickListener);
            table_main_btn_splitmergeprint.setOnClickListener(clickListener);
            table_main_btn_detailinfo.setOnClickListener(clickListener);
            table_main_btn_movetable.setOnClickListener(clickListener);
            table_main_btn_tablesplit.setOnClickListener(clickListener);
            table_main_btn_tablemerge.setOnClickListener(clickListener);
            table_main_btn_tableclear.setOnClickListener(clickListener);
            table_main_btn_bellstop.setOnClickListener(clickListener);

            // 08092023
            table_main_btn_tablecombine.setOnClickListener(clickListener);
        }
    }



    /*
     * Layout
     */
    private void setLayout(){
//        btn_pay = (Button) findViewById(R.id.popup_main_action_pay);
        btn_close = (Button) findViewById(R.id.popup_table_action_close);
        table_main_btn_billprint = (Button) findViewById(R.id.table_main_btn_billprint);
        table_main_btn_splitmergeprint = (Button) findViewById(R.id.table_main_btn_splitmergeprint);
        table_main_btn_detailinfo = (Button) findViewById(R.id.table_main_btn_detailinfo);
        table_main_btn_movetable = (Button) findViewById(R.id.table_main_btn_movetable);
        table_main_btn_tablesplit = (Button) findViewById(R.id.table_main_btn_tablesplit);
        table_main_btn_tablemerge = (Button) findViewById(R.id.table_main_btn_tablemerge);
        table_main_btn_tableclear = (Button) findViewById(R.id.table_main_btn_tableclear);
        table_main_btn_bellstop = (Button) findViewById(R.id.table_main_btn_bellstop);

        // 08092023
        table_main_btn_tablecombine = (Button) findViewById(R.id.table_main_btn_tablecombine);
    }

}